"""Contract-driven Qt setup editor for CFDX cases."""
from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDoubleSpinBox,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QMessageBox,
    QPushButton,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from .boundary_setup import FIELD_SPECS, SCALAR_TYPES, VELOCITY_TYPES
from .case import Case
from .initialization import InitializationMode, InitializationSpec
from .materials import MaterialSpec
from .physics_setup import (PHYSICS_SPECS, TURBULENCE_CATALOG, TURBULENCE_MODELS,
                            turbulence_model_from_case, validate_turbulence_selection)
from .setup_model import ParameterType


class CaseSetupPanel(QWidget):
    """Thin Qt adapter over the shared headless setup contracts."""

    changed = Signal()

    def __init__(self, case: Case, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.case = case
        self.tabs = QTabWidget(self)
        self.tabs.addTab(self._physics_tab(), "Physics")
        self.tabs.addTab(self._material_tab(), "Materials")
        self.tabs.addTab(self._boundary_tab(), "Boundaries")
        self.tabs.addTab(self._initialization_tab(), "Initialization")
        layout = QVBoxLayout(self)
        self.validation_summary = QLabel("No validation diagnostics")
        self.validation_summary.setWordWrap(True)
        layout.addWidget(self.validation_summary)
        layout.addWidget(self.tabs)

    @staticmethod
    def _real(value: float) -> QDoubleSpinBox:
        box = QDoubleSpinBox()
        box.setRange(-1e300, 1e300)
        box.setDecimals(10)
        box.setValue(value)
        return box

    def _physics_tab(self) -> QWidget:
        w = QWidget()
        form = QFormLayout(w)
        self.physics_model = QComboBox()
        self.physics_model.addItems([spec.key for spec in PHYSICS_SPECS])
        self.physics_enabled = QCheckBox("Enabled")
        self.physics_button = QPushButton("Apply physics")
        self.physics_fields_form = QFormLayout()
        form.addRow("Model", self.physics_model)
        form.addRow("", self.physics_enabled)
        form.addRow(self.physics_fields_form)
        form.addRow("", self.physics_button)
        self.physics_fields: dict[str, QWidget] = {}

        self.physics_model.currentTextChanged.connect(self._rebuild_physics_fields)
        self.physics_enabled.toggled.connect(self._update_physics_dependencies)
        self.physics_button.clicked.connect(self._apply_physics)
        self._rebuild_physics_fields(self.physics_model.currentText())
        return w

    def _clear_form(self, form: QFormLayout) -> None:
        while form.count():
            item = form.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()

    def _rebuild_physics_fields(self, model: str) -> None:
        self._clear_form(self.physics_fields_form)
        self.physics_fields = {}
        try:
            spec = next(item for item in PHYSICS_SPECS if item.key == model)
        except StopIteration:
            return
        current = self.case.physics.get(model, {})
        if model == "turbulence":
            normalized = turbulence_model_from_case(current)
            self.turbulence_family = QComboBox()
            families = sorted({item.family.value.upper() for item in TURBULENCE_CATALOG})
            self.turbulence_family.addItems(families)
            self.turbulence_family.setCurrentText(str(normalized.get("family", "RANS")))
            self.physics_fields["family"] = self.turbulence_family
            self.physics_fields_form.addRow("Turbulence family", self.turbulence_family)

            self.turbulence_wall = QComboBox()
            self.turbulence_wall.addItems(["resolved", "wall_function", "all_y_plus", "none"])
            self.turbulence_wall.setCurrentText(str(normalized.get("wall_treatment", "resolved")))
            self.physics_fields["wall_treatment"] = self.turbulence_wall
            self.physics_fields_form.addRow("Wall treatment", self.turbulence_wall)

            self.turbulence_family.currentTextChanged.connect(self._filter_turbulence_models)
        for field in spec.fields:
            if field.name == "model":
                box = QComboBox()
                self.physics_fields["model"] = box
                self._filter_turbulence_models(str(normalized.get("model", field.default)) if model == "turbulence" else str(current.get(field.name, field.default)))
                widget: QWidget = box
            elif field.kind is ParameterType.REAL:
                widget = self._real(float(current.get(field.name, field.default)))
            else:
                box = QComboBox()
                box.addItem(str(field.default))
                box.setCurrentText(str(current.get(field.name, field.default)))
                widget = box
            self.physics_fields[field.name] = widget
            label = field.name.replace("_", " ").title()
            if field.unit:
                label += f" [{field.unit}]"
            self.physics_fields_form.addRow(label, widget)
        self._update_physics_dependencies()

    def _filter_turbulence_models(self, preferred: str | None = None) -> None:
        box = self.physics_fields.get("model")
        family_box = self.physics_fields.get("family")
        if not isinstance(box, QComboBox) or not isinstance(family_box, QComboBox):
            return
        family = family_box.currentText().lower()
        choices = [
            item.key for item in TURBULENCE_CATALOG
            if item.status.value == "solver_ready" and item.family.value == family
        ]
        current = preferred or box.currentText()
        box.blockSignals(True)
        box.clear()
        box.addItems(choices)
        if current in choices:
            box.setCurrentText(current)
        box.blockSignals(False)

    def _update_physics_dependencies(self) -> None:
        model = self.physics_model.currentText()
        enabled_models = {
            key for key, value in self.case.physics.items()
            if isinstance(value, dict) and bool(value.get("enabled", True))
        }
        for spec in PHYSICS_SPECS:
            if spec.key == model:
                dependencies_ok = all(
                    dependency in enabled_models or dependency == model
                    for dependency in spec.requires
                )
                self.physics_enabled.setEnabled(dependencies_ok)
                if not dependencies_ok:
                    self.physics_enabled.setToolTip(
                        "Enable required models first: " + ", ".join(spec.requires)
                    )
                else:
                    self.physics_enabled.setToolTip("")
                return

    def _apply_physics(self) -> None:
        model = self.physics_model.currentText()
        values: dict[str, object] = {"enabled": self.physics_enabled.isChecked()}
        for spec in PHYSICS_SPECS:
            if spec.key != model:
                continue
            for field in spec.fields:
                widget = self.physics_fields.get(field.name)
                if widget is None:
                    continue
                if isinstance(widget, QDoubleSpinBox):
                    values[field.name] = widget.value()
                elif isinstance(widget, QComboBox):
                    values[field.name] = widget.currentText()
            break
        if model == "turbulence":
            try:
                values = validate_turbulence_selection(values)
            except ValueError as exc:
                QMessageBox.warning(self, "Turbulence selection", str(exc))
                return
        self.case.physics[model] = values
        self._update_physics_dependencies()
        self.changed.emit()

    def _material_tab(self) -> QWidget:
        w = QWidget()
        form = QFormLayout(w)
        self.material_name = QLineEdit()
        self.material_density = self._real(1.0)
        self.material_viscosity = self._real(1e-3)
        self.material_cp = self._real(1000.0)
        self.material_conductivity = self._real(0.0)
        self.material_button = QPushButton("Apply material")
        form.addRow("Name", self.material_name)
        form.addRow("Density [kg/m³]", self.material_density)
        form.addRow("Dynamic viscosity [Pa·s]", self.material_viscosity)
        form.addRow("Cp [J/(kg·K)]", self.material_cp)
        form.addRow("Conductivity [W/(m·K)]", self.material_conductivity)
        form.addRow("", self.material_button)
        self.material_button.clicked.connect(self._apply_material)
        return w

    def _boundary_tab(self) -> QWidget:
        w = QWidget()
        form = QFormLayout(w)
        self.boundary_list = QListWidget()
        self.boundary_name = QLineEdit()
        self.boundary_type = QComboBox()
        self.boundary_type.addItems(
            ["inlet", "outlet", "wall", "symmetry", "periodic", "interface", "empty"]
        )
        self.boundary_field = QComboBox()
        self.boundary_field.addItems(list(FIELD_SPECS))
        self.boundary_scalar_type = QComboBox()
        self.boundary_scalar_type.addItems(SCALAR_TYPES)
        self.boundary_value = self._real(0.0)
        self.boundary_gradient = self._real(0.0)
        self.boundary_x = self._real(0.0)
        self.boundary_y = self._real(0.0)
        self.boundary_z = self._real(0.0)
        self.boundary_button = QPushButton("Apply / Update")
        self.boundary_remove_button = QPushButton("Remove selected")
        form.addRow("Existing patches", self.boundary_list)
        form.addRow("Name", self.boundary_name)
        form.addRow("Patch type", self.boundary_type)
        form.addRow("Field", self.boundary_field)
        form.addRow("Scalar condition", self.boundary_scalar_type)
        form.addRow("Value", self.boundary_value)
        form.addRow("Gradient", self.boundary_gradient)
        form.addRow("Vector X [m/s]", self.boundary_x)
        form.addRow("Vector Y [m/s]", self.boundary_y)
        form.addRow("Vector Z [m/s]", self.boundary_z)
        row = QHBoxLayout()
        row.addWidget(self.boundary_button)
        row.addWidget(self.boundary_remove_button)
        form.addRow("", row)
        self.boundary_button.clicked.connect(self._apply_boundary)
        self.boundary_remove_button.clicked.connect(self._remove_boundary)
        self.boundary_list.currentTextChanged.connect(self._load_boundary)
        self.boundary_field.currentTextChanged.connect(self._update_boundary_field_controls)
        self._update_boundary_field_controls(self.boundary_field.currentText())
        self._refresh_boundaries()
        return w

    def _initialization_tab(self) -> QWidget:
        w = QWidget()
        form = QFormLayout(w)
        self.initialization_mode = QComboBox()
        self.initialization_mode.addItems([m.value for m in InitializationMode])
        self.initialization_field = QLineEdit("U")
        self.initialization_value = self._real(0.0)
        self.initialization_button = QPushButton("Apply initialization")
        form.addRow("Mode", self.initialization_mode)
        form.addRow("Field", self.initialization_field)
        form.addRow("Uniform value", self.initialization_value)
        form.addRow("", self.initialization_button)
        self.initialization_button.clicked.connect(self._apply_initialization)
        self.initialization_mode.currentTextChanged.connect(
            lambda mode: self.initialization_value.setEnabled(mode == "uniform")
        )
        return w

    def set_case(self, case: Case) -> None:
        self.case = case
        self._rebuild_physics_fields(self.physics_model.currentText())
        self._refresh_boundaries()

    def set_diagnostics(self, diagnostics) -> None:
        """Show feedback, select the relevant tab, and highlight its editor."""
        diagnostics = tuple(diagnostics)
        if not diagnostics:
            self.validation_summary.setText("No validation diagnostics")
            self.validation_summary.setStyleSheet("")
            return
        errors = sum(item.severity == "error" for item in diagnostics)
        self.validation_summary.setText(
            f"Validation: {errors} error(s), {len(diagnostics) - errors} warning(s)"
            + " — " + "; ".join(item.message for item in diagnostics[:3])
        )
        self.validation_summary.setStyleSheet(
            "color: #a40000;" if errors else "color: #8a5a00;"
        )
        widgets = (
            *self.physics_fields.values(),
            self.material_name,
            self.material_density,
            self.material_viscosity,
            self.material_cp,
            self.material_conductivity,
            self.boundary_name,
            self.boundary_type,
            self.boundary_field,
            self.boundary_scalar_type,
            self.boundary_value,
            self.boundary_gradient,
            self.boundary_x,
            self.boundary_y,
            self.boundary_z,
            self.initialization_mode,
            self.initialization_field,
            self.initialization_value,
        )
        for widget in widgets:
            widget.setStyleSheet("")
            widget.setToolTip("")
        for item in diagnostics:
            target, tab_index = self._diagnostic_target(item.path)
            if target is not None:
                self.tabs.setCurrentIndex(tab_index)
                target.setToolTip(f"{item.code}: {item.message}")
                target.setStyleSheet(
                    "border: 1px solid #a40000;" if item.severity == "error"
                    else "border: 1px solid #c58a00;"
                )

    def _diagnostic_target(self, path: str):
        """Resolve a validation path to a widget and its Setup tab."""
        parts = path.split(".")
        if parts[:1] == ["physics"]:
            if len(parts) == 2 and parts[1] == "initialization":
                return self.initialization_mode, 3
            if len(parts) >= 3:
                model, field = parts[1], parts[2]
                if model != self.physics_model.currentText():
                    self.physics_model.setCurrentText(model)
                return self.physics_fields.get(field), 0
            return None, 0
        if parts[:1] == ["materials"]:
            field = parts[2] if len(parts) >= 3 else None
            material_widgets = {
                "density": self.material_density,
                "dynamic_viscosity": self.material_viscosity,
                "cp": self.material_cp,
                "conductivity": self.material_conductivity,
            }
            return material_widgets.get(field, self.material_name), 1
        if parts[:1] == ["boundaries"]:
            if len(parts) >= 2:
                name = parts[1]
                row = self.boundary_list.findItems(name, Qt.MatchFlag.MatchExactly)
                if row:
                    self.boundary_list.setCurrentItem(row[0])
            field = parts[2] if len(parts) >= 3 else None
            boundary_widgets = {
                "type": self.boundary_type,
                "fields": self.boundary_field,
                "scalar_type": self.boundary_scalar_type,
                "value": self.boundary_value,
                "gradient": self.boundary_gradient,
                "velocity_type": self.boundary_scalar_type,
            }
            return boundary_widgets.get(field, self.boundary_name), 2
        return None, 0

    def _apply_material(self) -> None:
        name = self.material_name.text().strip()
        if not name:
            QMessageBox.warning(self, "Material", "Material name is required")
            return
        material = MaterialSpec(
            name,
            self.material_density.value(),
            self.material_viscosity.value(),
            self.material_cp.value(),
            self.material_conductivity.value(),
        )
        try:
            material.validate()
        except ValueError as exc:
            QMessageBox.warning(self, "Material validation", str(exc))
            return
        self.case.materials[name] = {
            "density": material.density,
            "dynamic_viscosity": material.dynamic_viscosity,
            "cp": material.cp,
            "conductivity": material.conductivity,
        }
        self.changed.emit()

    def _update_boundary_field_controls(self, field: str) -> None:
        vector = field == "velocity"
        for box in (self.boundary_x, self.boundary_y, self.boundary_z):
            box.setVisible(vector)
        self.boundary_value.setVisible(not vector)
        self.boundary_gradient.setVisible(not vector)
        self.boundary_scalar_type.clear()
        self.boundary_scalar_type.addItems(VELOCITY_TYPES if vector else SCALAR_TYPES)

    def _apply_boundary(self) -> None:
        name = self.boundary_name.text().strip()
        if not name:
            QMessageBox.warning(self, "Boundary", "Boundary name is required")
            return
        values: dict[str, object] = {"type": self.boundary_type.currentText()}
        if values["type"] not in {"periodic", "interface", "empty"}:
            field = self.boundary_field.currentText()
            values["fields"] = [field]
            if field == "velocity":
                values.update(
                    {
                        "velocity_type": self.boundary_scalar_type.currentText(),
                        "velocity_value": [
                            self.boundary_x.value(),
                            self.boundary_y.value(),
                            self.boundary_z.value(),
                        ],
                    }
                )
            else:
                values.update(
                    {
                        "scalar_type": self.boundary_scalar_type.currentText(),
                        "value": self.boundary_value.value(),
                        "gradient": self.boundary_gradient.value(),
                    }
                )
        existing = dict(self.case.boundaries.get(name, {}))
        supported_keys = {
            "type", "fields", "scalar_type", "value", "gradient",
            "velocity_type", "velocity_value",
        }
        preserved = {key: value for key, value in existing.items() if key not in supported_keys}
        preserved.update(values)
        self.case.set_boundary(name, **preserved)
        self._refresh_boundaries()
        self.changed.emit()

    def _remove_boundary(self) -> None:
        item = self.boundary_list.currentItem()
        if item is not None:
            self.case.boundaries.pop(item.text(), None)
            self._refresh_boundaries()
            self.changed.emit()

    def _refresh_boundaries(self) -> None:
        self.boundary_list.blockSignals(True)
        self.boundary_list.clear()
        self.boundary_list.addItems(list(self.case.boundaries))
        self.boundary_list.blockSignals(False)

    def _load_boundary(self, name: str) -> None:
        if not name:
            return
        boundary = self.case.boundaries.get(name, {})
        index = self.boundary_type.findText(str(boundary.get("type", "wall")))
        self.boundary_type.setCurrentIndex(max(0, index))
        field = str((boundary.get("fields") or ["pressure"])[0])
        index = self.boundary_field.findText(field)
        self.boundary_field.setCurrentIndex(max(0, index))
        index = self.boundary_scalar_type.findText(
            str(boundary.get("scalar_type", boundary.get("velocity_type", "ZERO_GRADIENT")))
        )
        self.boundary_scalar_type.setCurrentIndex(max(0, index))
        vector = boundary.get("velocity_value", [0.0, 0.0, 0.0])
        self.boundary_x.setValue(float(vector[0]))
        self.boundary_y.setValue(float(vector[1]))
        self.boundary_z.setValue(float(vector[2]))
        self.boundary_value.setValue(float(boundary.get("value", 0.0)))
        self.boundary_gradient.setValue(float(boundary.get("gradient", 0.0)))
        self.boundary_name.setText(name)

    def _apply_initialization(self) -> None:
        mode = InitializationMode(self.initialization_mode.currentText())
        field = self.initialization_field.text().strip()
        value = self.initialization_value.value() if mode is InitializationMode.UNIFORM else None
        spec = InitializationSpec(mode, field, value)
        try:
            spec.validate()
        except ValueError as exc:
            QMessageBox.warning(self, "Initialization validation", str(exc))
            return
        self.case.physics["initialization"] = {
            "mode": mode.value,
            "field": spec.field,
            "value": spec.value,
        }
        self.changed.emit()
