"""CFDX case/restart artifact persistence.

The HDF5 case is the persistent source of truth. A solver DAT file is kept
as a paired numerical-restart artifact when explicitly saved.
"""

from __future__ import annotations

import hashlib
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path

import h5py

from .case import Case, ExecutionConfig
from .dat_io import read_dat_restart, remap_dat_restart, write_dat_hdf5
from .probe import Probe
from .session import CFDXSession


_FORMAT = "CFDX"
_SCHEMA_VERSION = 1
_CASE_DATASET = "case/config"
_RUNTIME_ROOT = "runtime"
# Top-level names that carry solver runtime state. Numerical iteration/time and
# field state belongs exclusively to the paired DAT artifact, so their presence
# in a .cfdx.h5 bundle means the two artifacts were not separated.
_RUNTIME_STATE_NAMES = frozenset({
    "checkpoint", "history", "iteration", "iterations", "monitor",
    "monitor_series", "residual", "residuals", "restart", "solution",
    "solution_history", "time", "times",
})


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _canonical_case_hash(case_data: dict, mesh_hash: str | None = None) -> str:
    """Hash normalized case configuration plus the persisted mesh identity."""
    payload = {"case": case_data, "mesh_hash": mesh_hash}
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _validate_path(path: Path) -> Path:
    path = Path(path)
    if not path.name.lower().endswith(".cfdx.h5"):
        raise ValueError("CFDX case must use the canonical .cfdx.h5 extension")
    return path


def _paired_dat_path(case_path: Path) -> Path:
    """Return the canonical DAT sibling for case.cfdx.h5."""
    name = case_path.name
    if name.lower().endswith(".cfdx.h5"):
        name = name[:-len(".cfdx.h5")]
    else:
        name = case_path.stem
    return case_path.with_name(f"{name}.dat.h5")


def save_case(session: CFDXSession, path: Path) -> Path:
    """Save only the complete case definition to the canonical HDF5 artifact."""
    path = _validate_path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    case_data = session.case.as_dict()

    # Append to an existing CFDX HDF5 artifact so a mesh/topology written by
    # the native C++ HDF5 layer is never destroyed by a case save.
    with h5py.File(path, "a") as h5:
        h5.attrs["format"] = _FORMAT
        h5.attrs["schema_version"] = _SCHEMA_VERSION
        h5.attrs["case_revision"] = session.case_revision
        h5.attrs["mesh_revision"] = session.mesh_revision
        h5.attrs["physics_revision"] = session.physics_revision
        h5.attrs["numerics_revision"] = session.numerics_revision
        now = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        if "creation_date" not in h5.attrs:
            h5.attrs["creation_date"] = now
        h5.attrs["modification_date"] = now
        h5.attrs["dimension"] = int(h5.attrs.get("dimension", 3))
        h5.attrs["precision"] = str(h5.attrs.get("precision", "float64"))
        h5.attrs["endian"] = str(h5.attrs.get("endian", "little"))

        case_group = h5.require_group("case")
        if "config" in case_group:
            del case_group["config"]
        case_group.create_dataset(
            "config",
            data=json.dumps(case_data, sort_keys=True, separators=(",", ":")),
        )

        mesh_hash = h5.attrs.get("mesh_hash")
        if isinstance(mesh_hash, bytes):
            mesh_hash = mesh_hash.decode("utf-8")
        h5.attrs["case_hash"] = _canonical_case_hash(case_data, mesh_hash)
        if "geometry_hash" in h5.attrs:
            h5.attrs["geometry_hash"] = str(h5.attrs["geometry_hash"])

        # Numerical iteration/time/field state belongs exclusively to DAT.
        # The case remains the source of truth for setup/definition.

    return path


_CHECKPOINT_REVISION_NAMES = ("case_revision", "mesh_revision", "physics_revision", "numerics_revision")
_CHECKPOINT_SCHEMA_VERSION = 1


def _checkpoint_revision_attributes(session: CFDXSession) -> dict[str, int]:
    """Build the case identity a canonical checkpoint must be bound to."""
    attributes = {"checkpoint_schema_version": _CHECKPOINT_SCHEMA_VERSION}
    for name in _CHECKPOINT_REVISION_NAMES:
        value = getattr(session, name)
        if isinstance(value, bool) or not isinstance(value, int):
            raise ValueError(f"checkpoint field {name!r} must be an integer")
        if value < 0:
            raise ValueError(f"checkpoint field {name!r} must be non-negative")
        attributes[name] = value
    return attributes


def _validate_checkpoint_revisions(path: Path, session: CFDXSession) -> None:
    """Reject a DAT/HDF5 checkpoint not produced for this case identity.

    A checkpoint that carries no recognised schema is rejected before any
    numerical state is read, so an incompatible artifact is never partially
    consumed.
    """
    expected = _checkpoint_revision_attributes(session)
    with h5py.File(path, "r") as h5:
        schema = h5.attrs.get("checkpoint_schema_version", -1)
        try:
            schema = int(schema)
        except (TypeError, ValueError) as exc:
            raise ValueError("unsupported CFDX DAT checkpoint schema") from exc
        if schema != _CHECKPOINT_SCHEMA_VERSION:
            raise ValueError("unsupported CFDX DAT checkpoint schema")
        missing = [name for name in _CHECKPOINT_REVISION_NAMES if name not in h5.attrs]
        if missing:
            raise ValueError(
                "DAT checkpoint is missing compatibility metadata: " + ", ".join(missing)
            )
        actual = {}
        for name in _CHECKPOINT_REVISION_NAMES:
            try:
                actual[name] = int(h5.attrs[name])
            except (TypeError, ValueError) as exc:
                raise ValueError(
                    f"DAT checkpoint has a non-integer {name!r} binding"
                ) from exc
        mismatches = [name for name in _CHECKPOINT_REVISION_NAMES if actual[name] != expected[name]]
        if mismatches:
            details = ", ".join(f"{name}={actual[name]} expected={expected[name]}" for name in mismatches)
            raise ValueError("incompatible DAT checkpoint revisions: " + details)


def save_case_with_dat(
    session: CFDXSession, path: Path, dat_path: Path
) -> tuple[Path, Path]:
    """Save the case and canonicalize a numerical DAT checkpoint beside it."""
    dat_path = Path(dat_path)
    if not dat_path.is_file():
        raise FileNotFoundError(dat_path)

    case_path = save_case(session, path)
    target_dat = _paired_dat_path(case_path)
    restart = read_dat_restart(dat_path)
    write_dat_hdf5(
        target_dat, restart, attributes=_checkpoint_revision_attributes(session)
    )

    return case_path, target_dat


def _read_session(path: Path) -> CFDXSession:
    path = _validate_path(path)
    if not path.is_file():
        raise FileNotFoundError(path)

    with h5py.File(path, "r") as h5:
        file_format = h5.attrs.get("format")
        if isinstance(file_format, bytes):
            file_format = file_format.decode("utf-8")
        if file_format != _FORMAT:
            raise ValueError("not a CFDX HDF5 case")
        if int(h5.attrs.get("schema_version", -1)) != _SCHEMA_VERSION:
            raise ValueError("unsupported CFDX HDF5 case schema")

        try:
            raw = h5[_CASE_DATASET][()]
            if isinstance(raw, bytes):
                raw = raw.decode("utf-8")
            data = json.loads(raw)
            execution = ExecutionConfig(**data["execution"])
            case = Case(
                name=data["name"],
                physics=dict(data["physics"]),
                numerics=dict(data["numerics"]),
                boundaries=dict(data["boundaries"]),
                materials=dict(data.get("materials", {})),
                execution=execution,
                probes=[Probe.from_dict(item) for item in data.get("probes", [])],
            )
            # Loading a case never consumes numerical restart state.
            session = CFDXSession(
                case=case,
                case_revision=int(h5.attrs["case_revision"]),
                mesh_revision=int(h5.attrs["mesh_revision"]),
                physics_revision=int(h5.attrs["physics_revision"]),
                numerics_revision=int(h5.attrs["numerics_revision"]),
            )
        except (KeyError, TypeError, ValueError, json.JSONDecodeError) as exc:
            raise ValueError("invalid CFDX HDF5 case content") from exc

    return session


def validate_case_bundle(path: Path) -> dict[str, bool]:
    """Validate one self-contained CFDX HDF5 case artifact.

    ``runtime_separated`` reports that the bundle carries setup and mesh only:
    no ``runtime`` subtree and no top-level member named after solver runtime
    state. It recognises the runtime vocabulary this codebase writes, so an
    artifact that invents an unrelated synonym for iteration state would not be
    flagged by it.
    """
    case_path = _validate_path(path)
    if not case_path.is_file():
        raise FileNotFoundError(case_path)
    required_mesh = ("points", "face_vertices", "face_offsets", "owner", "neighbour", "cell_faces", "cell_offsets")
    with h5py.File(case_path, "r") as h5:
        if h5.attrs.get("format") != _FORMAT:
            raise ValueError("not a CFDX HDF5 case")
        if int(h5.attrs.get("schema_version", -1)) != _SCHEMA_VERSION:
            raise ValueError("unsupported CFDX HDF5 case schema")
        if _CASE_DATASET not in h5:
            raise ValueError("case configuration is missing")
        if not all(name in h5 for name in required_mesh):
            raise ValueError("mesh data is missing from the self-contained case")
        if "case_hash" not in h5.attrs:
            raise ValueError("case integrity hash is missing")
        mesh_hash = h5.attrs.get("mesh_hash")
        if isinstance(mesh_hash, bytes):
            mesh_hash = mesh_hash.decode("utf-8")
        raw = h5[_CASE_DATASET][()]
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8")
        data = json.loads(raw)
        expected_case_hash = _canonical_case_hash(data, mesh_hash)
        recorded_case_hash = h5.attrs["case_hash"]
        if isinstance(recorded_case_hash, bytes):
            recorded_case_hash = recorded_case_hash.decode("utf-8")
        if str(recorded_case_hash) != expected_case_hash:
            raise ValueError("case integrity hash mismatch")
        if "fields" not in h5 or "values" not in h5["fields"]:
            raise ValueError("fields data is missing from the self-contained case")
        if not isinstance(data.get("physics"), dict):
            raise ValueError("physics configuration is missing")
        if not isinstance(data.get("numerics"), dict):
            raise ValueError("numerics configuration is missing")
        # Numerical iteration/time/field state belongs exclusively to the
        # paired DAT artifact, so a well-formed case never carries runtime
        # state. Checking the two historical checkpoint/restart paths alone only
        # proved those two names were absent: an arbitrary runtime/* group, or
        # a top-level iteration/time/solution dataset, leaked state past it.
        # Any runtime subtree is therefore rejected outright, as is any
        # top-level member named after solver runtime state.
        unexpected_runtime = [
            name for name in h5
            if name == _RUNTIME_ROOT
            or name.rsplit("/", 1)[-1] in _RUNTIME_STATE_NAMES
        ]
        runtime_separated = (
            "case" in h5
            and _CASE_DATASET.rsplit("/", 1)[-1] in h5["case"]
            and not unexpected_runtime
        )
    return {"mesh": True, "fields": True, "physics": True, "numerics": True, "runtime_separated": runtime_separated}


def read_case(path: Path) -> CFDXSession:
    """Load only the HDF5 case; no solver restart artifact is consumed."""
    return _read_session(path)


def _read_case_cell_ids(path: Path) -> tuple[int, ...] | None:
    """Read persistent mesh cell IDs from the case when they are available."""
    with h5py.File(path, "r") as h5:
        if "cell_ids" not in h5:
            return None
        raw_ids = h5["cell_ids"][()]
    try:
        ids = tuple(int(value) for value in raw_ids)
    except (TypeError, ValueError) as exc:
        raise ValueError("case cell_ids must contain integer IDs for DAT restart") from exc
    if len(set(ids)) != len(ids):
        raise ValueError("case contains duplicate cell ids")
    if any(value < 0 for value in ids):
        raise ValueError("case contains negative cell ids")
    return ids


def read_case_with_dat(
    path: Path, dat_path: Path | None = None
) -> tuple[CFDXSession, Path]:
    """Load a case and restore its numerical state from a DAT checkpoint.

    The DAT field arrays become the session's authoritative in-memory field
    store. When both artifacts expose persistent cell IDs, field values are
    remapped into the case mesh ordering before being attached to the session.
    Without case IDs, DAT values are loaded in their stored order.
    """
    case_path = _validate_path(path)
    session = _read_session(case_path)

    candidate = Path(dat_path) if dat_path is not None else _paired_dat_path(case_path)
    if not candidate.is_file():
        raise FileNotFoundError(candidate)

    # The case identity is settled before the checkpoint is parsed: an
    # incompatible artifact must be rejected without its numerical state ever
    # entering the session.
    _validate_checkpoint_revisions(candidate, session)
    restart = read_dat_restart(candidate)
    case_cell_ids = _read_case_cell_ids(case_path)
    if case_cell_ids is not None:
        if restart.cell_ids is None:
            raise ValueError(
                "DAT restart has no persistent cell ids; cannot safely map it to the case mesh"
            )
        source_ids = set(restart.cell_ids)
        target_ids = set(case_cell_ids)
        missing = target_ids - source_ids
        extra = source_ids - target_ids
        if missing:
            raise ValueError(f"target cell id missing from checkpoint: {min(missing)}")
        if extra:
            raise ValueError(f"checkpoint cell id is absent from target mesh: {min(extra)}")
        restart = remap_dat_restart(restart, case_cell_ids)
    elif restart.cell_ids is not None:
        # Preserve the DAT's explicit ordering when the case does not carry a
        # persistent mesh identity yet.
        session.field_cell_ids = restart.cell_ids

    session.iteration = restart.iteration
    session.time = restart.time
    session.fields = dict(restart.fields)
    if case_cell_ids is not None:
        session.field_cell_ids = case_cell_ids
    return session, candidate
